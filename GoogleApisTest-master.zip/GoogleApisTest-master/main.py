from oauth2client.service_account import ServiceAccountCredentials
from googleapiclient.discovery import build as google_build_service
import httplib2


def main():
    packageName = 'uz.globens'
    sku = 'globens_2020'

    http = ServiceAccountCredentials.from_json_keyfile_name(
        filename='globens-in-app-purchase-mgmt-service-account.json',
        scopes='https://www.googleapis.com/auth/androidpublisher'
    ).authorize(httplib2.Http())

    service = google_build_service("androidpublisher", "v3", http=http)
    in_app_products = service.inappproducts().get(packageName=packageName, sku=sku)
    result = in_app_products.execute()
    print(result)


if __name__ == '__main__':
    main()
